
class SubSystemClassB:
    @staticmethod
    def method():
        return "B"