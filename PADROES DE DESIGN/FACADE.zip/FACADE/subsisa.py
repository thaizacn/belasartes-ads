
class SubSystemClassA:
    @staticmethod
    def method():
        return "A"